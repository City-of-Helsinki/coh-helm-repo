{{/*
Expand the name of the chart.
*/}}
{{- define "redis-sentinel.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
*/}}
{{- define "redis-sentinel.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "redis-sentinel.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "redis-sentinel.labels" -}}
helm.sh/chart: {{ include "redis-sentinel.chart" . }}
{{ include "redis-sentinel.selectorLabels" . }}
{{- with include "redis-cluster.appVersion" . }}
app.kubernetes.io/version: {{ . | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "redis-sentinel.selectorLabels" -}}
app.kubernetes.io/name: {{ include "redis-sentinel.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Redis labels
*/}}
{{- define "redis-sentinel.redis.labels" -}}
{{ include "redis-sentinel.labels" . }}
app.kubernetes.io/component: redis
{{- end }}

{{/*
Redis selector labels
*/}}
{{- define "redis-sentinel.redis.selectorLabels" -}}
{{ include "redis-sentinel.selectorLabels" . }}
app.kubernetes.io/component: redis
{{- end }}

{{/*
Sentinel labels
*/}}
{{- define "redis-sentinel.sentinel.labels" -}}
{{ include "redis-sentinel.labels" . }}
app.kubernetes.io/component: sentinel
{{- end }}

{{/*
Sentinel selector labels
*/}}
{{- define "redis-sentinel.sentinel.selectorLabels" -}}
{{ include "redis-sentinel.selectorLabels" . }}
app.kubernetes.io/component: sentinel
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "redis-sentinel.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "redis-sentinel.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
Render an image reference.
Input dict: { "image": <map|string>, "global": .Values.global }
  - string (non-empty) -> returned as-is (backwards compatible full reference)
  - map: registry (falls back to global.imageRegistry), repository, tag, digest (wins over tag)
No registry hostnames are hard-coded here; defaults live in values.yaml.
*/}}
{{- define "redis-sentinel.imageRef" -}}
{{- $img := .image -}}
{{- $global := .global | default dict -}}
{{- if kindIs "string" $img -}}
{{- $img -}}
{{- else -}}
{{- $registry := $img.registry | default $global.imageRegistry | default "" | trimSuffix "/" -}}
{{- $repo := required "image.repository is required" $img.repository -}}
{{- $ref := ternary (printf "%s/%s" $registry $repo) $repo (ne $registry "") -}}
{{- if $img.digest -}}
{{- printf "%s@%s" $ref $img.digest -}}
{{- else -}}
{{- printf "%s:%s" $ref (toString (required (printf "image tag is required for %s" $repo) $img.tag)) -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
Get the Redis image
*/}}
{{- define "redis-sentinel.redis.image" -}}
{{- include "redis-sentinel.imageRef" (dict "image" .Values.redis.image "global" .Values.global) -}}
{{- end }}

{{/*
Get the Sentinel image (defaults to the Redis image when sentinel.image is empty)
*/}}
{{- define "redis-sentinel.sentinel.image" -}}
{{- $img := .Values.sentinel.image -}}
{{- if or (not $img) (and (kindIs "map" $img) (not $img.repository)) -}}
{{- $img = .Values.redis.image -}}
{{- end -}}
{{- include "redis-sentinel.imageRef" (dict "image" $img "global" .Values.global) -}}
{{- end }}

{{/*
imagePullSecrets from global.imagePullSecrets + imagePullSecrets (deduplicated)
*/}}
{{- define "redis-sentinel.imagePullSecrets" -}}
{{- $out := list -}}
{{- range (concat ((.Values.global).imagePullSecrets | default list) (.Values.imagePullSecrets | default list)) -}}
{{- $out = append $out (ternary (dict "name" .) . (kindIs "string" .)) -}}
{{- end -}}
{{- $out = uniq $out -}}
{{- if $out -}}
imagePullSecrets:
{{ toYaml $out | indent 2 }}
{{- end -}}
{{- end -}}

{{/*
Get the redis password secret
*/}}
{{- define "redis-sentinel.redis.passwordSecret" -}}
{{- if .Values.redis.password.existingSecret }}
{{- .Values.redis.password.existingSecret }}
{{- else if .Values.redis.password.secretName }}
{{- .Values.redis.password.secretName | trunc 253 }}
{{- else }}
{{- include "redis-sentinel.fullname" . }}-secret
{{- end }}
{{- end }}

{{/*
Get the redis password key - Use REDIS_PASSWORD as default if not specified
*/}}
{{- define "redis-sentinel.redis.passwordKey" -}}
{{- if .Values.redis.password.existingSecret }}
    {{- .Values.redis.password.secretKey | default "REDIS_PASSWORD" }}
{{- else }}
    {{- "REDIS_PASSWORD" }}
{{- end }}
{{- end }}

{{/*
Generate Redis configuration with auto-merge (extraConfig wins)
*/}}
{{- define "redis-sentinel.redis.config" -}}
{{- $baseConfig := dict 
  "bind" (.Values.redis.config.bind | default "0.0.0.0")
  "protected-mode" (.Values.redis.config.protectedMode | default "yes")
  "port" (.Values.redis.config.port | default "6379")
  "timeout" (.Values.redis.config.timeout | default "500")
  "tcp-keepalive" (.Values.redis.config.tcpKeepalive | default "300")
  "tcp-backlog" (.Values.redis.config.tcpBacklog | default "511")
  
  "requirepass" (.Values.redis.config.requirepass | default "")
  
  "daemonize" (.Values.redis.config.daemonize | default "no")
  "supervised" (.Values.redis.config.supervised | default "no")
  "pidfile" (.Values.redis.config.pidfile | default "/var/run/redis_6379.pid")
  
  "loglevel" (.Values.redis.config.loglevel | default "notice")
  "logfile" (.Values.redis.config.logfile | default "")
  
  "databases" (.Values.redis.config.databases | default "16")
  
  "maxmemory" (.Values.redis.config.maxmemory | default "900mb")
  "maxmemory-policy" (.Values.redis.config.maxmemoryPolicy | default "allkeys-lru")
  
  "save" (.Values.redis.config.save | default "")
  "appendonly" (.Values.redis.config.appendonly | default "no")
  "stop-writes-on-bgsave-error" (.Values.redis.config.stopWritesOnBgsaveError | default "no")
  "rdbcompression" (.Values.redis.config.rdbcompression | default "yes")
  "rdbchecksum" (.Values.redis.config.rdbchecksum | default "yes")
  "rdb-del-sync-files" (.Values.redis.config.rdbDelSyncFiles | default "no")
  
  "replica-serve-stale-data" (.Values.redis.config.replicaServeStaleData | default "yes")
  "replica-read-only" (.Values.redis.config.replicaReadOnly | default "yes")
  "repl-diskless-sync" (.Values.redis.config.replDisklessSync | default "no")
  "repl-diskless-sync-delay" (.Values.redis.config.replDisklessSyncDelay | default "5")
  "repl-diskless-load" (.Values.redis.config.replDisklessLoad | default "disabled")
  "repl-disable-tcp-nodelay" (.Values.redis.config.replDisableTcpNodelay | default "no")
  "replica-priority" (.Values.redis.config.replicaPriority | default "100")
  
  "acllog-max-len" (.Values.redis.config.acllogMaxLen | default "128")
  
  "always-show-logo" (.Values.redis.config.alwaysShowLogo | default "yes")
  "dir" (.Values.redis.config.dir | default "/data")
-}}

{{- $finalConfig := $baseConfig -}}

{{- if .Values.redis.extraConfig }}
  {{- range $key, $value := .Values.redis.extraConfig }}
    {{- if not (empty $value) }}
      {{- $finalConfig = set $finalConfig $key $value }}
    {{- end }}
  {{- end }}
{{- end }}

{{- range $key, $value := $finalConfig }}
{{- if or (not (empty $value)) (eq $key "save") }}
{{ $key }} {{ $value }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Generate Sentinel configuration with auto-merge (extraConfig wins)
*/}}
{{- define "redis-sentinel.sentinel.config" -}}
{{- $masterName := .Values.sentinel.config.masterName | default "mymaster" -}}
{{- $redisMaster := (include "redis-sentinel.fullname" .) -}}
{{- $redisPort := .Values.redis.config.port | default 6379 | int -}}
{{- $redisMasterWithPort := printf "%s-0.%s-headless %d" $redisMaster $redisMaster $redisPort -}}
{{- $quorum := .Values.sentinel.config.quorum | default 2 | int -}}
{{- $downAfterMs := .Values.sentinel.config.downAfterMilliseconds | default 5000 | int -}}
{{- $failoverTimeout := .Values.sentinel.config.failoverTimeout | default 10000 | int -}}
{{- $parallelSyncs := .Values.sentinel.config.parallelSyncs | default 1 | int -}}

{{- $baseConfig := dict 
  "port" (.Values.sentinel.config.port | default 26379 | int)
  "sentinel resolve-hostnames" (.Values.sentinel.config.resolveHostnames | default "yes")
  "sentinel announce-hostnames" (.Values.sentinel.config.announceHostnames | default "yes")
-}}

{{- $baseConfig = set $baseConfig "sentinel monitor" (printf "%s %s %d" $masterName $redisMasterWithPort $quorum) -}}
{{- $baseConfig = set $baseConfig "sentinel down-after-milliseconds" (printf "%s %d" $masterName $downAfterMs) -}}
{{- $baseConfig = set $baseConfig "sentinel failover-timeout" (printf "%s %d" $masterName $failoverTimeout) -}}
{{- $baseConfig = set $baseConfig "sentinel parallel-syncs" (printf "%s %d" $masterName $parallelSyncs) -}}

{{- $finalConfig := $baseConfig -}}

{{- if .Values.sentinel.extraConfig }}
  {{- range $key, $value := .Values.sentinel.extraConfig }}
    {{- if not (empty $value) }}
      {{- $finalConfig = set $finalConfig $key $value }}
    {{- end }}
  {{- end }}
{{- end }}

{{- range $key, $value := $finalConfig }}
{{- if not (empty $value) }}
{{ $key }} {{ $value }}
{{- end }}
{{- end }}
{{- end }}
{{/*
Pod scheduling - the same contract in every coh chart:
  nodeSelector  map of node labels        (default {} = any node)
  tolerations   list of tolerations       (default [])
  affinity      Kubernetes affinity map   (default {})
Empty chart values fall back to global.nodeSelector / global.tolerations / global.affinity,
so a platform pipeline can set a default per region or cluster.
redis-cluster extra: when no affinity is set, a soft pod anti-affinity spreads the
pods of each component over nodes (podAntiAffinity.enabled, default true).
Legacy: affinity.enabled: true|false (old switch) is still understood.
Call with (dict "ctx" $ "component" "redis"|"sentinel").
*/}}
{{- define "redis-sentinel.scheduling" -}}
{{- $v := .ctx.Values -}}
{{- $g := $v.global | default dict -}}
{{- $ns := $v.nodeSelector | default $g.nodeSelector -}}
{{- $tol := $v.tolerations | default $g.tolerations -}}
{{- $userAff := $v.affinity | default dict -}}
{{- $anti := dict "podAntiAffinity" (dict "preferredDuringSchedulingIgnoredDuringExecution" (list (dict "weight" 100 "podAffinityTerm" (dict "topologyKey" "kubernetes.io/hostname" "labelSelector" (dict "matchExpressions" (list (dict "key" "app.kubernetes.io/name" "operator" "In" "values" (list "redis-sentinel")) (dict "key" "app.kubernetes.io/component" "operator" "In" "values" (list .component)))))))) -}}
{{- $aff := dict -}}
{{- if hasKey $userAff "enabled" -}}
{{- if $userAff.enabled }}{{ $aff = $anti }}{{ end -}}
{{- else if $userAff -}}
{{- $aff = $userAff -}}
{{- else if $g.affinity -}}
{{- $aff = $g.affinity -}}
{{- else -}}
{{- $pa := $v.podAntiAffinity | default dict -}}
{{- if or (not (hasKey $pa "enabled")) $pa.enabled -}}
{{- $aff = $anti -}}
{{- end -}}
{{- end -}}
{{- with $ns }}
nodeSelector:
{{ toYaml . | indent 2 }}
{{- end }}
{{- with $tol }}
tolerations:
{{ toYaml . | indent 2 }}
{{- end }}
{{- with $aff }}
affinity:
{{ toYaml . | indent 2 }}
{{- end }}
{{- end -}}

{{/*
app.kubernetes.io/version = tag of the image actually deployed (falls back to appVersion,
e.g. for a digest-only image). Sanitised to a valid label value.
*/}}
{{- define "redis-cluster.appVersion" -}}
{{- $ref := include "redis-sentinel.redis.image" . -}}
{{- $name := last (splitList "/" (first (splitList "@" $ref))) -}}
{{- $tag := "" -}}
{{- if contains ":" $name }}{{ $tag = last (splitList ":" $name) }}{{ end -}}
{{- $tag = $tag | default .Chart.AppVersion | toString -}}
{{- regexReplaceAll "[^A-Za-z0-9._-]" $tag "_" | trunc 63 | trimAll "-._" -}}
{{- end -}}
